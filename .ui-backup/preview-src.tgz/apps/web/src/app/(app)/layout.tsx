'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import type { ReactNode } from 'react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Bell,
  Check,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  ChevronsUpDown,
  KeyRound,
  LogOut,
  Menu,
  MailWarning,
  ShieldAlert,
  X,
} from 'lucide-react';
import { ApiError, api, post } from '@/lib/api';
import type { Me, Tenant } from '@/lib/api';
import { SessionContext } from '@/lib/session';
import type { SessionValue } from '@/lib/session';
import { NAV, breadcrumbs, matchNav } from '@/components/shell/nav';
import type { NavGroup } from '@/components/shell/nav';
import { Button, OverlayHost, SkeletonBlock, cx, toast } from '@/components/ui';

const COLLAPSE_KEY = 'erp.sidebar.collapsed';

const initials = (name: string) =>
  name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]!.toUpperCase())
    .join('') || 'S';

/** Closes a popover on outside click and Escape. */
function useDismiss(open: boolean, close: () => void) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const click = (e: MouseEvent) => {
      if (!ref.current?.contains(e.target as Node)) close();
    };
    const key = (e: KeyboardEvent) => e.key === 'Escape' && close();
    document.addEventListener('mousedown', click);
    window.addEventListener('keydown', key);
    return () => {
      document.removeEventListener('mousedown', click);
      window.removeEventListener('keydown', key);
    };
  }, [open, close]);
  return ref;
}

/* ----------------------------------------- sidebar ---------------------------------------- */

function SchoolSwitcher({
  value,
  collapsed,
  onSwitch,
}: {
  value: SessionValue;
  collapsed: boolean;
  onSwitch: (id: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const close = useCallback(() => setOpen(false), []);
  const ref = useDismiss(open, close);
  const schools = value.me.tenants.filter((t) => t.membershipStatus === 'active');
  const name = value.tenant?.name ?? 'No school selected';
  const multiple = schools.length > 1;

  const mark = (
    <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-brand-600 text-xs font-semibold text-white">
      {initials(value.tenant?.name ?? 'School')}
    </span>
  );

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        disabled={!multiple}
        onClick={() => setOpen((o) => !o)}
        aria-haspopup={multiple ? 'listbox' : undefined}
        aria-expanded={multiple ? open : undefined}
        title={collapsed ? name : undefined}
        className={cx(
          'flex w-full items-center gap-2.5 rounded-lg p-1.5 text-left transition-colors',
          multiple && 'hover:bg-slate-100',
          collapsed && 'justify-center',
        )}
      >
        {mark}
        {!collapsed && (
          <>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-sm font-semibold text-ink">{name}</span>
              <span className="block truncate text-xs text-slate-500">
                {value.tenant ? value.tenant.slug : 'School ERP'}
              </span>
            </span>
            {multiple && <ChevronsUpDown className="size-4 shrink-0 text-slate-400" aria-hidden />}
          </>
        )}
      </button>
      {open && (
        <div
          role="listbox"
          aria-label="Switch school"
          className="absolute top-full left-0 z-40 mt-1 w-64 animate-pop-in rounded-lg border border-line bg-white p-1 shadow-pop"
        >
          <p className="px-2.5 py-1.5 text-xs font-medium text-slate-500">Switch school</p>
          {schools.map((t) => (
            <button
              key={t.id}
              type="button"
              role="option"
              aria-selected={t.id === value.me.activeTenantId}
              onClick={() => {
                setOpen(false);
                if (t.id !== value.me.activeTenantId) onSwitch(t.id);
              }}
              className="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-left text-sm hover:bg-slate-100"
            >
              <span className="flex size-6 items-center justify-center rounded-md bg-slate-100 text-[10px] font-semibold text-slate-600">
                {initials(t.name)}
              </span>
              <span className="min-w-0 flex-1 truncate">{t.name}</span>
              {t.id === value.me.activeTenantId && (
                <Check className="size-4 text-brand-600" aria-hidden />
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function NavLinks({
  groups,
  pathname,
  collapsed,
  onNavigate,
}: {
  groups: NavGroup[];
  pathname: string;
  collapsed: boolean;
  onNavigate?: () => void;
}) {
  const activeHref = matchNav(pathname, groups)?.item.href;
  return (
    <nav aria-label="Main" className="flex flex-col gap-4 px-3 py-3">
      {groups.map((group, gi) => (
        <div key={group.section}>
          {collapsed ? (
            gi > 0 && <div className="mx-2 mb-3 border-t border-slate-200" aria-hidden />
          ) : (
            <p className="px-2.5 pb-1 text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
              {group.section}
            </p>
          )}
          <ul className="flex flex-col gap-px">
            {group.items.map((item) => {
              const active = item.href === activeHref;
              const Icon = item.icon;
              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    aria-current={active ? 'page' : undefined}
                    title={collapsed ? item.label : undefined}
                    onClick={onNavigate}
                    className={cx(
                      'group flex h-8 items-center gap-2.5 rounded-md px-2.5 text-[13.5px] transition-colors',
                      collapsed && 'justify-center px-0',
                      active
                        ? 'bg-brand-50 font-medium text-brand-700'
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900',
                    )}
                  >
                    <Icon
                      aria-hidden
                      className={cx(
                        'size-4 shrink-0',
                        active ? 'text-brand-600' : 'text-slate-400 group-hover:text-slate-600',
                      )}
                    />
                    {!collapsed && <span className="truncate">{item.label}</span>}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </nav>
  );
}

/* ----------------------------------------- top bar ---------------------------------------- */

function Notifications({ value }: { value: SessionValue }) {
  const [open, setOpen] = useState(false);
  const close = useCallback(() => setOpen(false), []);
  const ref = useDismiss(open, close);
  const [sending, setSending] = useState(false);

  // Only real, actionable account notices — nothing is invented.
  const items: Array<{ id: string; icon: typeof Bell; title: string; body: ReactNode }> = [];
  if (!value.me.user.emailVerified)
    items.push({
      id: 'email',
      icon: MailWarning,
      title: 'Confirm your email address',
      body: (
        <button
          type="button"
          disabled={sending}
          className="font-medium text-brand-700 hover:underline disabled:opacity-50"
          onClick={async () => {
            setSending(true);
            try {
              await post('/auth/email/resend');
              toast.success('Confirmation email sent.');
            } catch {
              toast.error('Could not send the email. Try again shortly.');
            } finally {
              setSending(false);
            }
          }}
        >
          Resend link
        </button>
      ),
    });
  if (value.me.mfaEnforced && !value.me.user.mfaEnabled)
    items.push({
      id: 'mfa',
      icon: ShieldAlert,
      title: 'Two-step verification required',
      body: (
        <Link href="/account/security" onClick={close} className="font-medium text-brand-700 hover:underline">
          Turn it on
        </Link>
      ),
    });

  return (
    <div ref={ref} className="relative">
      <Button
        type="button"
        variant="ghost"
        icon={Bell}
        aria-label={`Notifications${items.length ? ` (${items.length})` : ''}`}
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
        className="relative"
      />
      {items.length > 0 && (
        <span
          aria-hidden
          className="pointer-events-none absolute top-2 right-2 size-2 rounded-full bg-red-500 ring-2 ring-white"
        />
      )}
      {open && (
        <div className="absolute right-0 z-40 mt-1 w-80 animate-pop-in rounded-xl border border-line bg-white shadow-pop">
          <p className="border-b border-slate-100 px-4 py-2.5 text-sm font-semibold">Notifications</p>
          {items.length ? (
            <ul className="divide-y divide-slate-100">
              {items.map((i) => (
                <li key={i.id} className="flex gap-3 px-4 py-3">
                  <i.icon className="mt-0.5 size-4 shrink-0 text-amber-600" aria-hidden />
                  <div className="text-sm">
                    <p className="font-medium text-ink">{i.title}</p>
                    <div className="mt-0.5 text-[13px]">{i.body}</div>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <p className="px-4 py-8 text-center text-[13px] text-slate-500">You’re all caught up.</p>
          )}
        </div>
      )}
    </div>
  );
}

function UserMenu({ value, onLogout }: { value: SessionValue; onLogout: () => void }) {
  const [open, setOpen] = useState(false);
  const close = useCallback(() => setOpen(false), []);
  const ref = useDismiss(open, close);
  const { fullName, email } = value.me.user;
  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="menu"
        aria-expanded={open}
        className="flex h-9 items-center gap-2 rounded-lg pr-2 pl-1 transition-colors hover:bg-slate-100"
      >
        <span className="flex size-7 items-center justify-center rounded-full bg-slate-800 text-[11px] font-semibold text-white">
          {initials(fullName)}
        </span>
        <span className="hidden max-w-40 truncate text-sm font-medium text-slate-700 sm:inline">
          {fullName}
        </span>
      </button>
      {open && (
        <div
          role="menu"
          className="absolute right-0 z-40 mt-1 w-60 animate-pop-in rounded-xl border border-line bg-white p-1 shadow-pop"
        >
          <div className="px-3 py-2.5">
            <p className="truncate text-sm font-medium text-ink">{fullName}</p>
            <p className="truncate text-xs text-slate-500">{email}</p>
          </div>
          <div className="my-1 border-t border-slate-100" />
          <Link
            role="menuitem"
            href="/account/security"
            onClick={close}
            className="flex items-center gap-2 rounded-md px-3 py-2 text-sm text-slate-700 hover:bg-slate-100"
          >
            <KeyRound className="size-4 text-slate-400" aria-hidden />
            Account & security
          </Link>
          <button
            role="menuitem"
            type="button"
            onClick={onLogout}
            className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-sm text-slate-700 hover:bg-slate-100"
          >
            <LogOut className="size-4 text-slate-400" aria-hidden />
            Sign out
          </button>
        </div>
      )}
    </div>
  );
}

/* ----------------------------------------- layout ----------------------------------------- */

export default function AppLayout({ children }: { children: ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [me, setMe] = useState<Me | null>(null);
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [loadError, setLoadError] = useState(false);

  useEffect(() => {
    try {
      setCollapsed(localStorage.getItem(COLLAPSE_KEY) === '1');
    } catch {
      /* storage unavailable */
    }
  }, []);
  const toggleCollapsed = () =>
    setCollapsed((c) => {
      try {
        localStorage.setItem(COLLAPSE_KEY, c ? '0' : '1');
      } catch {
        /* storage unavailable */
      }
      return !c;
    });

  // Close the mobile drawer on navigation.
  useEffect(() => setDrawerOpen(false), [pathname]);

  // Fetch the user and the active school together and commit both at once, so the
  // shell never renders with a user but no school (which looked like "no access").
  const load = useCallback(async () => {
    try {
      const m = await api<Me>('/auth/me');
      let t: Tenant | null = null;
      if (m.activeTenantId) {
        try {
          t = await api<Tenant>('/tenant');
        } catch (e) {
          // Membership/school no longer usable: treat as "no active school".
          // Anything else (network, 5xx) is a load failure, not a lack of access.
          if (!(e instanceof ApiError && (e.status === 403 || e.status === 404))) throw e;
        }
      }
      setMe(m);
      setTenant(t);
      setLoadError(false);
    } catch (e) {
      if (e instanceof ApiError && (e.status === 401 || e.body.code === 'MFA_REQUIRED')) {
        router.replace('/login');
        return;
      }
      setLoadError(true);
    }
  }, [router]);

  useEffect(() => {
    void load();
  }, [load]);

  const value = useMemo<SessionValue | null>(
    () =>
      me && {
        me,
        tenant,
        can: (p: string, campusId?: string) => {
          if (!tenant?.permissions.includes(p)) return false;
          if (!campusId) return true;
          const scope = tenant.permissionScopes?.[p];
          return scope === null || scope === undefined || scope.includes(campusId);
        },
        canEverywhere: (p: string) =>
          Boolean(tenant?.permissions.includes(p) && tenant.permissionScopes?.[p] === null),
        reload: load,
      },
    [me, tenant, load],
  );

  const groups = useMemo(
    () =>
      value
        ? NAV.map((g) => ({
            ...g,
            items: g.items.filter(
              (i) =>
                !i.permission ||
                (Array.isArray(i.permission) ? i.permission : [i.permission]).some((p) =>
                  value.can(p),
                ),
            ),
          })).filter((g) => g.items.length)
        : [],
    [value],
  );

  // Lock page scroll while the mobile drawer is open.
  useEffect(() => {
    if (!drawerOpen) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const key = (e: KeyboardEvent) => e.key === 'Escape' && setDrawerOpen(false);
    window.addEventListener('keydown', key);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener('keydown', key);
    };
  }, [drawerOpen]);

  if (!value && loadError) {
    return (
      <div className="flex min-h-dvh items-center justify-center p-6">
        <div
          role="alert"
          className="w-full max-w-sm rounded-xl border border-line bg-white p-6 text-center shadow-card"
        >
          <p className="font-semibold text-ink">We couldn’t load your account</p>
          <p className="mt-1 text-sm text-slate-500">Check your connection and try again.</p>
          <Button className="mt-4" onClick={() => void load()}>
            Try again
          </Button>
        </div>
      </div>
    );
  }

  if (!value) {
    return (
      <div className="flex min-h-dvh" aria-busy="true" aria-label="Loading">
        <div className="hidden w-64 shrink-0 border-r border-line bg-white p-4 md:block">
          <SkeletonBlock className="h-9 w-full" />
          <div className="mt-6 space-y-2">
            {Array.from({ length: 8 }, (_, i) => (
              <SkeletonBlock key={i} className="h-7 w-full" />
            ))}
          </div>
        </div>
        <div className="flex-1">
          <div className="h-14 border-b border-line bg-white" />
          <div className="mx-auto max-w-7xl space-y-4 p-6 lg:p-8">
            <SkeletonBlock className="h-7 w-56" />
            <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
              {Array.from({ length: 4 }, (_, i) => (
                <SkeletonBlock key={i} className="h-24" />
              ))}
            </div>
            <SkeletonBlock className="h-64" />
          </div>
        </div>
      </div>
    );
  }

  const switchTenant = async (id: string) => {
    try {
      await post('/auth/switch-tenant', { tenantId: id });
      await load();
      router.push('/dashboard');
    } catch {
      toast.error('Could not switch school. Try again.');
    }
  };

  const logout = async () => {
    await post('/auth/logout').catch(() => undefined);
    router.replace('/login');
  };

  const crumbs = breadcrumbs(pathname, groups);

  const sidebarBody = (isDrawer: boolean) => {
    const small = collapsed && !isDrawer;
    return (
      <>
        <div className={cx('flex h-14 shrink-0 items-center border-b border-line px-3', small && 'px-2')}>
          <div className="min-w-0 flex-1">
            <SchoolSwitcher value={value} collapsed={small} onSwitch={(id) => void switchTenant(id)} />
          </div>
          {isDrawer && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              icon={X}
              aria-label="Close menu"
              onClick={() => setDrawerOpen(false)}
            />
          )}
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain [scrollbar-width:thin]">
          <NavLinks
            groups={groups}
            pathname={pathname}
            collapsed={small}
            onNavigate={isDrawer ? () => setDrawerOpen(false) : undefined}
          />
        </div>
        {!isDrawer && (
          <div className="shrink-0 border-t border-line p-2">
            <button
              type="button"
              onClick={toggleCollapsed}
              aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
              title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
              className={cx(
                'flex h-8 w-full items-center gap-2 rounded-md px-2.5 text-[13px] text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-800',
                collapsed && 'justify-center px-0',
              )}
            >
              {collapsed ? (
                <ChevronsRight className="size-4" aria-hidden />
              ) : (
                <>
                  <ChevronsLeft className="size-4" aria-hidden />
                  Collapse
                </>
              )}
            </button>
          </div>
        )}
      </>
    );
  };

  return (
    <SessionContext.Provider value={value}>
      <a
        href="#main"
        className="sr-only z-50 rounded-md bg-white px-3 py-2 text-sm font-medium shadow-pop focus:not-sr-only focus:fixed focus:top-2 focus:left-2"
      >
        Skip to content
      </a>

      {/* Desktop sidebar */}
      <aside
        className={cx(
          'fixed inset-y-0 left-0 z-30 hidden flex-col border-r border-line bg-white transition-[width] duration-200 md:flex',
          collapsed ? 'w-16' : 'w-64',
        )}
      >
        {sidebarBody(false)}
      </aside>

      {/* Mobile drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 md:hidden" role="dialog" aria-modal="true" aria-label="Menu">
          <div
            className="absolute inset-0 animate-fade-in bg-slate-900/40"
            onClick={() => setDrawerOpen(false)}
            aria-hidden
          />
          <aside className="relative flex h-full w-72 max-w-[85vw] animate-slide-in-left flex-col bg-white shadow-pop">
            {sidebarBody(true)}
          </aside>
        </div>
      )}

      <div
        className={cx(
          'flex min-h-dvh min-w-0 flex-col transition-[padding] duration-200',
          collapsed ? 'md:pl-16' : 'md:pl-64',
        )}
      >
        <header className="sticky top-0 z-20 flex h-14 shrink-0 items-center gap-3 border-b border-line bg-white/90 px-4 backdrop-blur sm:px-6 lg:px-8">
          <Button
            type="button"
            variant="ghost"
            icon={Menu}
            aria-label="Open menu"
            aria-expanded={drawerOpen}
            onClick={() => setDrawerOpen(true)}
            className="-ml-2 md:hidden"
          />
          <nav aria-label="Breadcrumb" className="min-w-0 flex-1">
            <ol className="flex min-w-0 items-center gap-1.5 text-sm">
              {crumbs.map((c, i) => {
                const last = i === crumbs.length - 1;
                return (
                  <li
                    key={`${c.label}-${i}`}
                    className={cx('flex min-w-0 items-center gap-1.5', !last && 'hidden sm:flex')}
                  >
                    {i > 0 && <ChevronRight className="size-3.5 shrink-0 text-slate-300" aria-hidden />}
                    {last ? (
                      <span aria-current="page" className="truncate font-medium text-ink">
                        {c.label}
                      </span>
                    ) : c.href ? (
                      <Link href={c.href} className="truncate text-slate-500 hover:text-slate-800">
                        {c.label}
                      </Link>
                    ) : (
                      <span className="truncate text-slate-500">{c.label}</span>
                    )}
                  </li>
                );
              })}
            </ol>
          </nav>
          <div className="flex items-center gap-1">
            <Notifications value={value} />
            <div className="mx-1 h-6 w-px bg-slate-200" aria-hidden />
            <UserMenu value={value} onLogout={() => void logout()} />
          </div>
        </header>

        <main id="main" className="w-full flex-1 px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
          <div className="mx-auto w-full max-w-[1400px]">{children}</div>
        </main>
      </div>
      <OverlayHost />
    </SessionContext.Provider>
  );
}
