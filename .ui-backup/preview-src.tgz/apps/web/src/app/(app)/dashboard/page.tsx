'use client';

import Link from 'next/link';
import type { ReactNode } from 'react';
import {
  ArrowRight,
  CalendarCheck,
  CalendarDays,
  CheckCircle2,
  Circle,
  ClipboardCheck,
  GraduationCap,
  History,
  IndianRupee,
  Layers,
  ListTodo,
  Receipt,
  UserCheck,
  UserPlus,
  Users,
} from 'lucide-react';
import { post } from '@/lib/api';
import type {
  AcademicYear,
  ApplicationSummary,
  AttendanceToday,
  AuditEntry,
  CalendarEntry,
  DemandList,
  GradeLevel,
  Inquiry,
  LeaveRequest,
  Member,
  PaymentList,
  Section,
  StudentListItem,
} from '@/lib/api';
import { dateTime, formatDate, formatRange, fullName } from '@/lib/format';
import { useAction, useApi } from '@/lib/use-api';
import { useSession } from '@/lib/session';
import { useCampus } from '@/components/academic/campus-picker';
import { localToday, shiftDate } from '@/components/attendance/status';
import { inr } from '@/components/fees/money';
import {
  Alert,
  Badge,
  ButtonLink,
  Card,
  EmptyState,
  SkeletonBlock,
  StatCard,
  cx,
  toast,
} from '@/components/ui';

const ATTENDANCE_ANY = ['attendance.view', 'attendance.mark', 'attendance.correct'];
const FEES_ANY = ['fees.view', 'fees.configure', 'fees.collect', 'fees.concession.approve'];

const KIND_TONE = { holiday: 'red', vacation: 'amber', event: 'blue', exam: 'neutral' } as const;
const KIND_LABEL = { holiday: 'Holiday', vacation: 'Vacation', event: 'Event', exam: 'Exam' };

const n = (v: number) => v.toLocaleString('en-IN');

function greeting() {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
}

/** Compact list used by dashboard panels. */
function PanelList({
  loading,
  empty,
  children,
}: {
  loading: boolean;
  empty: ReactNode;
  children: ReactNode[];
}) {
  if (loading)
    return (
      <div className="space-y-3 p-5">
        {Array.from({ length: 4 }, (_, i) => (
          <SkeletonBlock key={i} className="h-5" />
        ))}
      </div>
    );
  if (!children.length) return <>{empty}</>;
  return <ul className="divide-y divide-slate-100">{children}</ul>;
}

function PanelLink({ href, children }: { href: string; children: ReactNode }) {
  return (
    <Link
      href={href}
      className="inline-flex items-center gap-1 text-[13px] font-medium text-brand-700 hover:text-brand-800"
    >
      {children}
      <ArrowRight className="size-3.5" aria-hidden />
    </Link>
  );
}

/* --------------------------------------- onboarding --------------------------------------- */

interface Step {
  key: string;
  label: string;
  description: string;
  done: boolean;
  href?: string;
  action?: ReactNode;
}

function Onboarding({ steps }: { steps: Step[] }) {
  const done = steps.filter((s) => s.done).length;
  const pct = Math.round((done / steps.length) * 100);
  const next = steps.find((s) => !s.done);
  return (
    <Card
      title="Set up your school"
      description={`${done} of ${steps.length} steps complete`}
      className="mb-6"
      flush
      actions={
        <div className="flex w-40 items-center gap-2">
          <div
            className="h-1.5 flex-1 overflow-hidden rounded-full bg-slate-100"
            role="progressbar"
            aria-valuenow={pct}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-label="Setup progress"
          >
            <div className="h-full rounded-full bg-brand-600 transition-all" style={{ width: `${pct}%` }} />
          </div>
          <span className="text-xs font-medium text-slate-500 tabular-nums">{pct}%</span>
        </div>
      }
    >
      <ol className="divide-y divide-slate-100">
        {steps.map((s, i) => {
          const isNext = s.key === next?.key;
          return (
            <li
              key={s.key}
              className={cx('flex items-center gap-3.5 px-5 py-3', isNext && 'bg-brand-50/40')}
            >
              {s.done ? (
                <CheckCircle2 className="size-5 shrink-0 text-emerald-600" aria-label="Done" />
              ) : (
                <span
                  className={cx(
                    'flex size-5 shrink-0 items-center justify-center rounded-full border text-[11px] font-semibold',
                    isNext ? 'border-brand-600 text-brand-700' : 'border-slate-300 text-slate-400',
                  )}
                  aria-label="Not done"
                >
                  {i + 1}
                </span>
              )}
              <div className="min-w-0 flex-1">
                <p
                  className={cx(
                    'text-sm font-medium',
                    s.done ? 'text-slate-400 line-through decoration-slate-300' : 'text-ink',
                  )}
                >
                  {s.label}
                </p>
                {!s.done && <p className="text-[13px] text-slate-500">{s.description}</p>}
              </div>
              {!s.done &&
                (s.action ??
                  (s.href && (
                    <ButtonLink href={s.href} size="sm" variant={isNext ? 'primary' : 'secondary'}>
                      {isNext ? 'Start' : 'Open'}
                    </ButtonLink>
                  )))}
            </li>
          );
        })}
      </ol>
    </Card>
  );
}

/* ----------------------------------------- page ------------------------------------------ */

export default function DashboardPage() {
  const { me, tenant, can, canEverywhere } = useSession();
  const { campus, campuses, picker, loading: campusLoading } = useCampus();
  const resend = useAction();
  const cid = campus?.id;
  const today = localToday();

  const any = (ps: string[]) => ps.some((p) => can(p, cid));
  const seeAcademic = can('academic.view');
  const seeStudents = can('students.view', cid) || can('students.view_assigned', cid);
  const seeAttendance = Boolean(cid) && any(ATTENDANCE_ANY);
  const seeFees = Boolean(cid) && any(FEES_ANY);
  const seeAdmissions = can('admissions.view');
  const seeMembers = can('members.view');

  const years = useApi<AcademicYear[]>(cid ? `/academic-years?campusId=${cid}` : null);
  const year =
    years.data?.find((y) => y.isCurrent) ??
    years.data?.findLast((y) => y.status !== 'closed') ??
    years.data?.at(-1) ??
    null;
  const yid = year?.id;

  const classes = useApi<GradeLevel[]>(seeAcademic && cid ? `/classes?campusId=${cid}` : null);
  const sections = useApi<Section[]>(seeAcademic && yid ? `/sections?academicYearId=${yid}` : null);
  const members = useApi<Member[]>(seeMembers ? '/members' : null);
  const attendance = useApi<AttendanceToday>(
    seeAttendance ? `/attendance/today?campusId=${cid}` : null,
  );
  const leave = useApi<LeaveRequest[]>(
    seeAttendance ? `/attendance/leave?campusId=${cid}&status=pending` : null,
  );
  const dues = useApi<DemandList>(
    seeFees && yid ? `/fees/demands?campusId=${cid}&academicYearId=${yid}&status=due&page=1` : null,
  );
  const overdue = useApi<DemandList>(
    seeFees && yid
      ? `/fees/demands?campusId=${cid}&academicYearId=${yid}&status=overdue&page=1`
      : null,
  );
  const payments = useApi<PaymentList>(
    seeFees ? `/fees/payments?campusId=${cid}&from=${today}&to=${today}&page=1` : null,
  );
  const applications = useApi<ApplicationSummary>(
    seeAdmissions && cid && yid
      ? `/applications/summary?campusId=${cid}&academicYearId=${yid}`
      : null,
  );
  const inquiries = useApi<{ data: Inquiry[]; nextCursor: string | null }>(
    seeAdmissions ? '/inquiries?limit=25&status=new' : null,
  );
  const recent = useApi<{ data: StudentListItem[]; nextCursor: string | null }>(
    seeStudents && cid ? `/students?campusId=${cid}&limit=6` : null,
  );
  const events = useApi<CalendarEntry[]>(
    seeAcademic && cid ? `/calendar?campusId=${cid}&from=${today}&to=${shiftDate(today, 45)}` : null,
  );
  const audit = useApi<{ data: AuditEntry[]; nextCursor: string | null }>(
    can('audit.view') ? '/audit-logs?limit=6' : null,
  );

  const firstName = me.user.fullName.split(' ')[0];
  const activeClasses = classes.data?.filter((c) => c.status === 'active') ?? [];
  const activeStaff = members.data?.filter((m) => m.status === 'active') ?? [];
  const att = attendance.data;
  const attPct =
    att && att.totals.students && att.totals.marked
      ? Math.round(
          ((att.totals.present + att.totals.late + att.totals.halfDay) /
            Math.max(
              1,
              att.totals.present +
                att.totals.late +
                att.totals.halfDay +
                att.totals.absent +
                att.totals.leave,
            )) *
            100,
        )
      : null;
  const pendingApps = applications.data
    ? (['submitted', 'under_review', 'assessment', 'approved', 'waitlisted'] as const).reduce(
        (sum, s) => sum + (applications.data!.byStatus[s] ?? 0),
        0,
      )
    : 0;

  /* ---------------- onboarding (only facts we can actually check) ---------------- */
  const steps: Step[] = [];
  steps.push({
    key: 'email',
    label: 'Verify your email',
    description: 'We sent a confirmation link to your inbox.',
    done: me.user.emailVerified,
    action: (
      <button
        type="button"
        className="text-[13px] font-medium text-brand-700 hover:underline disabled:opacity-50"
        disabled={resend.pending}
        onClick={async () => {
          if (await resend.run(() => post('/auth/email/resend')))
            toast.success('Confirmation email sent.');
        }}
      >
        {resend.pending ? 'Sending…' : 'Resend link'}
      </button>
    ),
  });
  if (can('settings.manage')) {
    const c = campuses[0];
    steps.push({
      key: 'profile',
      label: 'Complete school profile',
      description: 'Add your address, phone and contact email.',
      done: Boolean(c?.address && c?.phone),
      href: c ? '/settings/campuses' : '/settings/school',
    });
    steps.push({
      key: 'campus',
      label: 'Add campuses',
      description: 'Each branch of your school is a campus with its own classes.',
      done: campuses.length > 0,
      href: '/settings/campuses',
    });
  }
  if (canEverywhere('academic.manage') || can('academic.manage', cid)) {
    steps.push({
      key: 'year',
      label: 'Set up academic year',
      description: 'Define session dates, terms and weekly offs.',
      done: Boolean(years.data?.length),
      href: '/academics/years',
    });
    steps.push({
      key: 'classes',
      label: 'Create classes and sections',
      description: 'Use the ready-made structure or add classes yourself.',
      done: activeClasses.length > 0 && Boolean(sections.data?.length),
      href: '/academics/classes',
    });
  }
  if (can('members.manage')) {
    steps.push({
      key: 'staff',
      label: 'Invite teachers and staff',
      description: 'Give your team access with the right roles.',
      done: (members.data?.length ?? 0) > 1,
      href: '/settings/members',
    });
  }
  const setupLoading =
    campusLoading ||
    (years.loading && !years.data) ||
    (classes.loading && !classes.data) ||
    (members.loading && !members.data);
  const showOnboarding = !setupLoading && steps.length > 1 && steps.some((s) => !s.done);

  /* ------------------------------------- tasks ------------------------------------- */
  const tasks: Array<{ label: string; count: number; href: string; tone: 'amber' | 'red' | 'blue' }> =
    [];
  if (att && att.day.working && att.totals.sections > att.totals.marked)
    tasks.push({
      label: 'Sections without attendance today',
      count: att.totals.sections - att.totals.marked,
      href: '/attendance',
      tone: 'amber',
    });
  if (leave.data?.length)
    tasks.push({
      label: 'Leave requests awaiting decision',
      count: leave.data.length,
      href: '/attendance/leave',
      tone: 'amber',
    });
  if (inquiries.data?.data.length)
    tasks.push({
      label: 'New admission inquiries',
      count: inquiries.data.data.length,
      href: '/admissions/inquiries',
      tone: 'blue',
    });
  if (pendingApps)
    tasks.push({
      label: 'Applications in progress',
      count: pendingApps,
      href: '/admissions/applications',
      tone: 'blue',
    });
  if (overdue.data?.total)
    tasks.push({
      label: 'Overdue fee installments',
      count: overdue.data.total,
      href: '/fees?status=overdue',
      tone: 'red',
    });
  const tasksLoading =
    (seeAttendance && ((attendance.loading && !att) || (leave.loading && !leave.data))) ||
    (seeAdmissions && inquiries.loading && !inquiries.data) ||
    (seeFees && Boolean(yid) && overdue.loading && !overdue.data);

  /* ----------------------------------- quick actions ----------------------------------- */
  const quick = [
    can('students.manage') && { href: '/students/new', label: 'Admit student', icon: UserPlus },
    (can('attendance.mark') || can('attendance.correct')) && {
      href: '/attendance/mark',
      label: 'Take attendance',
      icon: ClipboardCheck,
    },
    can('fees.collect') && { href: '/fees/collect', label: 'Collect fee', icon: IndianRupee },
  ].filter(Boolean) as Array<{ href: string; label: string; icon: typeof UserPlus }>;

  return (
    <>
      {/* Welcome */}
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div className="min-w-0">
          <h1 className="text-xl font-semibold tracking-tight text-ink sm:text-[22px]">
            {greeting()}, {firstName}
          </h1>
          <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-sm text-slate-500">
            {tenant ? (
              <>
                <span className="font-medium text-slate-700">{tenant.name}</span>
                {campus && campuses.length > 1 && (
                  <>
                    <span aria-hidden>·</span>
                    <span>{campus.name}</span>
                  </>
                )}
                {year && (
                  <>
                    <span aria-hidden>·</span>
                    <span>Session {year.name}</span>
                  </>
                )}
              </>
            ) : (
              'You are not part of a school yet.'
            )}
          </p>
        </div>
        <div className="flex flex-wrap items-end gap-2">
          {campuses.length > 1 && <div className="w-56">{picker}</div>}
          {quick.map((q, i) => (
            <ButtonLink key={q.href} href={q.href} icon={q.icon} variant={i === 0 ? 'primary' : 'secondary'}>
              {q.label}
            </ButtonLink>
          ))}
        </div>
      </div>

      {me.mfaEnforced && !me.user.mfaEnabled && (
        <Alert
          tone="warning"
          className="mb-6"
          title="Two-step verification is required"
          action={<ButtonLink href="/account/security" size="sm">Turn on</ButtonLink>}
        >
          You need it before you can change settings, roles or staff access.
        </Alert>
      )}
      {resend.error && <Alert className="mb-6">{resend.error.message}</Alert>}

      {showOnboarding && <Onboarding steps={steps} />}

      {/* Overview cards */}
      <div className="mb-6 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3 xl:grid-cols-6">
        {seeAttendance && (
          <StatCard
            label="Enrolled students"
            icon={GraduationCap}
            value={att ? n(att.totals.students) : '—'}
            hint={att ? `in ${n(att.totals.sections)} sections` : undefined}
            loading={attendance.loading && !att}
            href={seeStudents ? '/students' : undefined}
          />
        )}
        {seeMembers && (
          <StatCard
            label="Active staff"
            icon={Users}
            value={n(activeStaff.length)}
            hint={
              members.data && members.data.length > activeStaff.length
                ? `${members.data.length - activeStaff.length} invited or suspended`
                : undefined
            }
            loading={members.loading && !members.data}
            href="/settings/members"
          />
        )}
        {seeAcademic && (
          <StatCard
            label="Classes"
            icon={Layers}
            value={n(activeClasses.length)}
            hint={sections.data ? `${n(sections.data.length)} sections this session` : undefined}
            loading={(classes.loading && !classes.data) || campusLoading}
            href="/academics/classes"
          />
        )}
        {seeAttendance && (
          <StatCard
            label="Today's attendance"
            icon={CalendarCheck}
            value={attPct === null ? '—' : `${attPct}%`}
            hint={
              att
                ? !att.day.working
                  ? 'Not a working day'
                  : `${n(att.totals.marked)} of ${n(att.totals.sections)} sections marked`
                : undefined
            }
            loading={attendance.loading && !att}
            href="/attendance"
          />
        )}
        {seeFees && (
          <StatCard
            label="Fees outstanding"
            icon={IndianRupee}
            value={dues.data ? inr(dues.data.totals.balance) : '—'}
            hint={dues.data ? `${n(dues.data.total)} installments due` : year ? undefined : 'No session'}
            loading={dues.loading && !dues.data}
            href="/fees"
          />
        )}
        {seeAdmissions && (
          <StatCard
            label="New admissions"
            icon={UserCheck}
            value={applications.data ? n(applications.data.byStatus.admitted ?? 0) : '—'}
            hint={year ? `Session ${year.name}` : undefined}
            loading={applications.loading && !applications.data}
            href="/admissions/applications"
          />
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Main column */}
        <div className="flex min-w-0 flex-col gap-6 lg:col-span-2">
          {seeAttendance && (
            <Card
              title="Today's attendance"
              icon={CalendarCheck}
              description={att ? formatDate(att.date) : undefined}
              actions={<PanelLink href="/attendance">Details</PanelLink>}
            >
              {attendance.loading && !att ? (
                <SkeletonBlock className="h-20" />
              ) : attendance.error ? (
                <Alert>{attendance.error.message}</Alert>
              ) : att && !att.day.working ? (
                <EmptyState compact icon={CalendarDays} title="No school today">
                  Attendance isn’t taken on holidays and weekly offs.
                </EmptyState>
              ) : att ? (
                <AttendanceSummary att={att} />
              ) : null}
            </Card>
          )}

          {seeStudents && (
            <Card
              title="Recent admissions"
              icon={UserPlus}
              flush
              actions={<PanelLink href="/students">All students</PanelLink>}
            >
              {recent.error ? (
                <div className="p-5">
                  <Alert>{recent.error.message}</Alert>
                </div>
              ) : (
                <PanelList
                  loading={recent.loading && !recent.data}
                  empty={
                    <EmptyState
                      compact
                      icon={Users}
                      title="No students yet"
                      action={
                        can('students.manage') ? (
                          <ButtonLink href="/students/new" size="sm" variant="primary">
                            Admit a student
                          </ButtonLink>
                        ) : undefined
                      }
                    />
                  }
                >
                  {(recent.data?.data ?? []).map((s) => (
                    <li key={s.id}>
                      <Link
                        href={`/students/${s.id}`}
                        className="flex items-center gap-3 px-5 py-2.5 transition-colors hover:bg-slate-50"
                      >
                        <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-slate-100 text-xs font-semibold text-slate-600">
                          {(s.firstName[0] ?? '') + (s.lastName[0] ?? '')}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm font-medium text-ink">
                            {fullName(s)}
                          </span>
                          <span className="block truncate text-xs text-slate-500">
                            {s.admissionNumber}
                            {s.className && ` · ${s.className}${s.sectionName ? ` ${s.sectionName}` : ''}`}
                          </span>
                        </span>
                        {s.status !== 'active' && <Badge>{s.status}</Badge>}
                      </Link>
                    </li>
                  ))}
                </PanelList>
              )}
            </Card>
          )}

          {seeFees && (
            <Card
              title="Fee collection"
              icon={Receipt}
              actions={<PanelLink href="/fees/receipts">Receipts</PanelLink>}
            >
              {(payments.loading && !payments.data) || (dues.loading && !dues.data) ? (
                <SkeletonBlock className="h-20" />
              ) : payments.error ? (
                <Alert>{payments.error.message}</Alert>
              ) : (
                <div className="grid gap-4 sm:grid-cols-3">
                  <Metric
                    label="Collected today"
                    value={payments.data ? inr(payments.data.totalAmount) : '—'}
                    hint={payments.data ? `${n(payments.data.total)} receipts` : undefined}
                  />
                  <Metric
                    label="Outstanding"
                    value={dues.data ? inr(dues.data.totals.balance) : '—'}
                    hint={dues.data ? `${n(dues.data.total)} installments due` : undefined}
                  />
                  <Metric
                    label="Overdue"
                    value={overdue.data ? inr(overdue.data.totals.balance) : '—'}
                    hint={overdue.data ? `${n(overdue.data.total)} installments` : undefined}
                    danger={Boolean(overdue.data?.totals.balance)}
                  />
                </div>
              )}
              {payments.data && payments.data.byMode.length > 0 && (
                <div className="mt-4 flex flex-wrap gap-2 border-t border-slate-100 pt-4">
                  {payments.data.byMode.map((m) => (
                    <Badge key={m.mode}>
                      {m.mode.replace('_', ' ').toUpperCase()} · {inr(m.amount)}
                    </Badge>
                  ))}
                </div>
              )}
            </Card>
          )}
        </div>

        {/* Side column */}
        <div className="flex min-w-0 flex-col gap-6">
          <Card title="Pending tasks" icon={ListTodo} flush>
            {tasksLoading ? (
              <div className="space-y-3 p-5">
                <SkeletonBlock className="h-5" />
                <SkeletonBlock className="h-5" />
              </div>
            ) : tasks.length ? (
              <ul className="divide-y divide-slate-100">
                {tasks.map((t) => (
                  <li key={t.label}>
                    <Link
                      href={t.href}
                      className="flex items-center justify-between gap-3 px-5 py-3 text-sm transition-colors hover:bg-slate-50"
                    >
                      <span className="text-slate-700">{t.label}</span>
                      <Badge tone={t.tone}>{n(t.count)}{t.count === 25 && t.href.includes('inquir') ? '+' : ''}</Badge>
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState compact icon={CheckCircle2} title="Nothing waiting on you" />
            )}
          </Card>

          {seeAcademic && (
            <Card
              title="Upcoming events"
              icon={CalendarDays}
              flush
              actions={<PanelLink href="/academics/calendar">Calendar</PanelLink>}
            >
              <PanelList
                loading={events.loading && !events.data}
                empty={<EmptyState compact icon={CalendarDays} title="Nothing in the next 45 days" />}
              >
                {(events.data ?? []).slice(0, 5).map((e) => (
                  <li key={e.id} className="flex items-start gap-3 px-5 py-2.5">
                    <DateChip iso={e.startsOn} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-ink">{e.title}</p>
                      <p className="text-xs text-slate-500">{formatRange(e.startsOn, e.endsOn)}</p>
                    </div>
                    <Badge tone={KIND_TONE[e.kind]}>{KIND_LABEL[e.kind]}</Badge>
                  </li>
                ))}
              </PanelList>
            </Card>
          )}

          {can('audit.view') && (
            <Card
              title="Recent activity"
              icon={History}
              flush
              actions={<PanelLink href="/settings/audit">Audit log</PanelLink>}
            >
              <PanelList
                loading={audit.loading && !audit.data}
                empty={<EmptyState compact icon={History} title="No activity yet" />}
              >
                {(audit.data?.data ?? []).map((a) => (
                  <li key={a.id} className="flex gap-3 px-5 py-2.5">
                    <Circle className="mt-1.5 size-2 shrink-0 fill-slate-300 text-slate-300" aria-hidden />
                    <div className="min-w-0 text-sm">
                      <p className="text-slate-700">
                        <span className="font-medium text-ink">{a.actorName ?? 'System'}</span>{' '}
                        {a.action.replaceAll('_', ' ').replaceAll('.', ' ')}
                      </p>
                      <p className="text-xs text-slate-500">{dateTime(a.createdAt)}</p>
                    </div>
                  </li>
                ))}
              </PanelList>
            </Card>
          )}
        </div>
      </div>
    </>
  );
}

function Metric({
  label,
  value,
  hint,
  danger,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  danger?: boolean;
}) {
  return (
    <div className="min-w-0">
      <p className="text-[13px] text-slate-500">{label}</p>
      <p
        className={cx(
          'mt-1 truncate text-lg font-semibold tabular-nums',
          danger ? 'text-red-700' : 'text-ink',
        )}
      >
        {value}
      </p>
      {hint && <p className="truncate text-xs text-slate-500">{hint}</p>}
    </div>
  );
}

function DateChip({ iso }: { iso: string }) {
  const [y, m, d] = iso.split('-').map(Number);
  const dt = new Date(Date.UTC(y!, m! - 1, d!));
  return (
    <span className="flex w-10 shrink-0 flex-col items-center rounded-md border border-line py-0.5">
      <span className="text-[10px] font-medium text-slate-500 uppercase">
        {dt.toLocaleDateString('en-IN', { month: 'short', timeZone: 'UTC' })}
      </span>
      <span className="text-sm leading-tight font-semibold text-ink tabular-nums">{d}</span>
    </span>
  );
}

function AttendanceSummary({ att }: { att: AttendanceToday }) {
  const t = att.totals;
  const parts = [
    { label: 'Present', value: t.present, cls: 'bg-emerald-500' },
    { label: 'Late', value: t.late, cls: 'bg-emerald-300' },
    { label: 'Half day', value: t.halfDay, cls: 'bg-amber-400' },
    { label: 'On leave', value: t.leave, cls: 'bg-slate-300' },
    { label: 'Absent', value: t.absent, cls: 'bg-red-500' },
  ];
  const recorded = parts.reduce((s, p) => s + p.value, 0);
  if (!t.marked)
    return (
      <EmptyState
        compact
        icon={ClipboardCheck}
        title="Attendance not taken yet"
        action={
          <ButtonLink href="/attendance/mark" size="sm" variant="primary">
            Take attendance
          </ButtonLink>
        }
      >
        {n(t.sections)} sections are waiting to be marked today.
      </EmptyState>
    );
  return (
    <div>
      <div className="flex h-2.5 overflow-hidden rounded-full bg-slate-100" aria-hidden>
        {parts.map((p) =>
          p.value ? (
            <div key={p.label} className={p.cls} style={{ width: `${(p.value / Math.max(1, recorded)) * 100}%` }} />
          ) : null,
        )}
      </div>
      <dl className="mt-4 grid grid-cols-3 gap-4 sm:grid-cols-6">
        {parts.map((p) => (
          <div key={p.label}>
            <dt className="flex items-center gap-1.5 text-xs text-slate-500">
              <span className={cx('size-2 rounded-full', p.cls)} aria-hidden />
              {p.label}
            </dt>
            <dd className="mt-0.5 text-base font-semibold text-ink tabular-nums">{n(p.value)}</dd>
          </div>
        ))}
        <div>
          <dt className="text-xs text-slate-500">Sections marked</dt>
          <dd className="mt-0.5 text-base font-semibold text-ink tabular-nums">
            {n(t.marked)}/{n(t.sections)}
          </dd>
        </div>
      </dl>
    </div>
  );
}
