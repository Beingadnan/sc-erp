import type { LucideIcon } from 'lucide-react';
import {
  Award,
  BadgePercent,
  BarChart3,
  BookOpen,
  Building2,
  CalendarCheck,
  CalendarDays,
  CalendarRange,
  CalendarX2,
  ClipboardCheck,
  FileStack,
  FileText,
  Globe,
  Hash,
  History,
  IndianRupee,
  KeyRound,
  Landmark,
  Layers,
  LayoutDashboard,
  ListPlus,
  LockKeyhole,
  MapPin,
  MessageSquareText,
  Receipt,
  ShieldCheck,
  SlidersHorizontal,
  Table2,
  Tags,
  TrendingDown,
  TrendingUp,
  Upload,
  UserCog,
  UserPlus,
  Users,
  Wallet,
} from 'lucide-react';

export interface NavItem {
  href: string;
  label: string;
  icon: LucideIcon;
  /** Shown only with this permission (any scope); a list means any of them. */
  permission?: string | string[];
}

export interface NavGroup {
  section: string;
  items: NavItem[];
}

const ATTENDANCE_ANY = ['attendance.view', 'attendance.mark', 'attendance.correct'];
const FEES_ANY = ['fees.view', 'fees.configure', 'fees.collect', 'fees.concession.approve'];

export const NAV: NavGroup[] = [
  {
    section: 'Overview',
    items: [{ href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard }],
  },
  {
    section: 'School management',
    items: [
      { href: '/settings/school', label: 'School profile', icon: Building2 },
      { href: '/settings/campuses', label: 'Campuses', icon: MapPin },
      {
        href: '/settings/admission-numbers',
        label: 'Admission numbers',
        icon: Hash,
        permission: 'students.manage',
      },
    ],
  },
  {
    section: 'Academics',
    items: [
      { href: '/academics/years', label: 'Academic years', icon: CalendarRange, permission: 'academic.view' },
      { href: '/academics/classes', label: 'Classes & sections', icon: Layers, permission: 'academic.view' },
      { href: '/academics/subjects', label: 'Subjects', icon: BookOpen, permission: 'academic.view' },
      { href: '/academics/calendar', label: 'Calendar', icon: CalendarDays, permission: 'academic.view' },
      { href: '/academics/grading', label: 'Grading', icon: Award, permission: 'academic.view' },
    ],
  },
  {
    section: 'Students',
    items: [
      {
        href: '/students',
        label: 'Students',
        icon: Users,
        permission: ['students.view', 'students.view_assigned'],
      },
      { href: '/students/new', label: 'Admit student', icon: UserPlus, permission: 'students.manage' },
      { href: '/students/promote', label: 'Promotion', icon: TrendingUp, permission: 'students.promote' },
      { href: '/students/import', label: 'Import students', icon: Upload, permission: 'students.import' },
    ],
  },
  {
    section: 'Admissions',
    items: [
      { href: '/admissions/inquiries', label: 'Inquiries', icon: MessageSquareText, permission: 'admissions.view' },
      { href: '/admissions/applications', label: 'Applications', icon: FileText, permission: 'admissions.view' },
    ],
  },
  {
    section: 'Attendance',
    items: [
      { href: '/attendance', label: "Today's attendance", icon: CalendarCheck, permission: ATTENDANCE_ANY },
      {
        href: '/attendance/mark',
        label: 'Take attendance',
        icon: ClipboardCheck,
        permission: ['attendance.mark', 'attendance.correct'],
      },
      { href: '/attendance/register', label: 'Monthly register', icon: Table2, permission: ATTENDANCE_ANY },
      { href: '/attendance/leave', label: 'Leave management', icon: CalendarX2, permission: ATTENDANCE_ANY },
      { href: '/attendance/low', label: 'Low attendance', icon: TrendingDown, permission: ATTENDANCE_ANY },
      {
        href: '/settings/attendance',
        label: 'Attendance settings',
        icon: SlidersHorizontal,
        permission: ['attendance.view', 'attendance.correct'],
      },
    ],
  },
  {
    section: 'Fees',
    items: [
      { href: '/fees/collect', label: 'Fee counter', icon: IndianRupee, permission: 'fees.collect' },
      { href: '/fees', label: 'Fee dues', icon: Wallet, permission: FEES_ANY },
      { href: '/fees/receipts', label: 'Receipts', icon: Receipt, permission: FEES_ANY },
      { href: '/fees/day-close', label: 'Day closing', icon: LockKeyhole, permission: FEES_ANY },
      { href: '/fees/structures', label: 'Fee structures', icon: FileStack, permission: FEES_ANY },
      { href: '/fees/concessions', label: 'Concessions', icon: BadgePercent, permission: FEES_ANY },
      { href: '/fees/heads', label: 'Fee heads', icon: Tags, permission: FEES_ANY },
      { href: '/fees/accounts', label: 'Accounts', icon: Landmark, permission: FEES_ANY },
      { href: '/fees/reports', label: 'Fee reports', icon: BarChart3, permission: FEES_ANY },
    ],
  },
  {
    section: 'Staff',
    items: [
      { href: '/settings/members', label: 'Staff & access', icon: UserCog, permission: 'members.view' },
      { href: '/settings/roles', label: 'Roles & permissions', icon: ShieldCheck, permission: 'members.view' },
    ],
  },
  {
    section: 'Website',
    items: [{ href: '/website', label: 'Website pages', icon: Globe, permission: 'cms.manage' }],
  },
  {
    section: 'Settings',
    items: [
      { href: '/settings/custom-fields', label: 'Custom fields', icon: ListPlus, permission: 'settings.manage' },
      { href: '/settings/audit', label: 'Audit log', icon: History, permission: 'audit.view' },
      { href: '/account/security', label: 'Account security', icon: KeyRound },
    ],
  },
];

/** The nav item a path belongs to: the longest matching href. */
export function matchNav(pathname: string, groups: NavGroup[] = NAV) {
  let best: { group: NavGroup; item: NavItem } | null = null;
  for (const group of groups)
    for (const item of group.items) {
      const hit = pathname === item.href || pathname.startsWith(`${item.href}/`);
      if (hit && (!best || item.href.length > best.item.href.length)) best = { group, item };
    }
  return best;
}

/** Labels for pages below a nav item (detail and nested pages). */
const SUB_PAGES: Array<[RegExp, string[]]> = [
  [/^\/students\/[^/]+\/fees$/, ['Student', 'Fee account']],
  [/^\/students\/(?!new$|promote$|import$)[^/]+$/, ['Student profile']],
  [/^\/fees\/structures\/[^/]+$/, ['Structure details']],
  [/^\/admissions\/applications\/new$/, ['New application']],
  [/^\/admissions\/applications\/[^/]+$/, ['Application']],
  [/^\/website\/[^/]+$/, ['Edit page']],
];

export interface Crumb {
  label: string;
  href?: string;
}

export function breadcrumbs(pathname: string, groups: NavGroup[]): Crumb[] {
  const m = matchNav(pathname, groups) ?? matchNav(pathname);
  if (!m) return [];
  const crumbs: Crumb[] = [{ label: m.group.section }];
  const sub = SUB_PAGES.find(([re]) => re.test(pathname))?.[1];
  crumbs.push({ label: m.item.label, href: sub ? m.item.href : undefined });
  if (sub) {
    // "/students/:id/fees" → Student (links to profile) → Fee account
    if (sub.length === 2) {
      crumbs.push({ label: sub[0]!, href: pathname.replace(/\/[^/]+$/, '') });
      crumbs.push({ label: sub[1]! });
    } else crumbs.push({ label: sub[0]! });
  }
  return crumbs;
}
