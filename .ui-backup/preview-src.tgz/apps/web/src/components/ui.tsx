'use client';

/**
 * Design system primitives. Every page builds on these so spacing, sizing and colour stay
 * consistent. Keep additions here generic; page-specific UI belongs next to the page.
 */

import Link from 'next/link';
import type {
  ButtonHTMLAttributes,
  ComponentProps,
  InputHTMLAttributes,
  ReactNode,
  SelectHTMLAttributes,
  TextareaHTMLAttributes,
} from 'react';
import { useEffect, useId, useRef, useState, useSyncExternalStore } from 'react';
import { createPortal } from 'react-dom';
import type { LucideIcon } from 'lucide-react';
import {
  AlertCircle,
  AlertTriangle,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Info,
  Inbox,
  MoreHorizontal,
  Search,
  X,
} from 'lucide-react';

export const cx = (...c: Array<string | false | null | undefined>) => c.filter(Boolean).join(' ');

/* ------------------------------------------------------------------------------------ */
/* Buttons                                                                              */
/* ------------------------------------------------------------------------------------ */

type Variant = 'primary' | 'secondary' | 'danger' | 'ghost';
type Size = 'sm' | 'md';

const buttonClass = (variant: Variant, size: Size, iconOnly = false) =>
  cx(
    'inline-flex shrink-0 select-none items-center justify-center gap-1.5 whitespace-nowrap rounded-lg font-medium transition-colors',
    'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600',
    'disabled:pointer-events-none disabled:opacity-50',
    size === 'md' ? 'h-9 text-sm' : 'h-8 text-[13px]',
    iconOnly ? (size === 'md' ? 'w-9' : 'w-8') : size === 'md' ? 'px-3.5' : 'px-2.5',
    variant === 'primary' && 'bg-brand-600 text-white shadow-card hover:bg-brand-700',
    variant === 'secondary' &&
      'border border-slate-300 bg-white text-slate-800 shadow-card hover:border-slate-400 hover:bg-slate-50',
    variant === 'danger' && 'bg-red-600 text-white shadow-card hover:bg-red-700',
    variant === 'ghost' && 'text-slate-700 hover:bg-slate-100 hover:text-slate-900',
  );

/** Button look for plain anchors (downloads, external links). */
export const buttonStyles = (variant: Variant = 'secondary', size: Size = 'md') =>
  buttonClass(variant, size);

export function Spinner({ className }: { className?: string }) {
  return (
    <span
      aria-hidden="true"
      className={cx(
        'inline-block size-3.5 animate-spin rounded-full border-2 border-current border-r-transparent',
        className,
      )}
    />
  );
}

export function Button({
  variant = 'primary',
  size = 'md',
  icon: Icon,
  loading,
  className,
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: Variant;
  size?: Size;
  icon?: LucideIcon;
  loading?: boolean;
}) {
  const iconOnly = Boolean(Icon) && (children === undefined || children === null);
  return (
    <button
      {...props}
      disabled={props.disabled || loading}
      aria-busy={loading || undefined}
      className={cx(buttonClass(variant, size, iconOnly), className)}
    >
      {loading ? <Spinner /> : Icon ? <Icon className="size-4" aria-hidden="true" /> : null}
      {children}
    </button>
  );
}

/** A link that looks like a button. */
export function ButtonLink({
  variant = 'secondary',
  size = 'md',
  icon: Icon,
  className,
  children,
  ...props
}: ComponentProps<typeof Link> & { variant?: Variant; size?: Size; icon?: LucideIcon }) {
  return (
    <Link {...props} className={cx(buttonClass(variant, size, !children && Boolean(Icon)), className)}>
      {Icon && <Icon className="size-4" aria-hidden="true" />}
      {children}
    </Link>
  );
}

/* ------------------------------------------------------------------------------------ */
/* Form controls                                                                        */
/* ------------------------------------------------------------------------------------ */

function FieldShell({
  id,
  label,
  required,
  error,
  hint,
  className,
  children,
}: {
  id: string;
  label: ReactNode;
  required?: boolean;
  error?: string;
  hint?: ReactNode;
  className?: string;
  children: ReactNode;
}) {
  return (
    <div className={cx('flex min-w-0 flex-col gap-1.5', className)}>
      <label htmlFor={id} className="text-[13px] font-medium text-slate-700">
        {label}
        {required && (
          <span className="ml-0.5 text-red-500" aria-hidden="true">
            *
          </span>
        )}
      </label>
      {children}
      {(error || hint) && (
        <p
          id={`${id}-msg`}
          className={cx('text-xs leading-snug', error ? 'text-red-600' : 'text-slate-500')}
        >
          {error ?? hint}
        </p>
      )}
    </div>
  );
}

export function Field({
  label,
  error,
  hint,
  className,
  ...props
}: InputHTMLAttributes<HTMLInputElement> & { label: ReactNode; error?: string; hint?: ReactNode }) {
  const id = useId();
  return (
    <FieldShell
      id={props.id ?? id}
      label={label}
      required={props.required}
      error={error}
      hint={hint}
      className={className}
    >
      <input
        id={props.id ?? id}
        {...props}
        aria-invalid={Boolean(error) || undefined}
        aria-describedby={error || hint ? `${props.id ?? id}-msg` : undefined}
        className="ui-control"
      />
    </FieldShell>
  );
}

export function SelectField({
  label,
  error,
  hint,
  children,
  className,
  ...props
}: SelectHTMLAttributes<HTMLSelectElement> & {
  label: ReactNode;
  error?: string;
  hint?: ReactNode;
}) {
  const id = useId();
  return (
    <FieldShell
      id={id}
      label={label}
      required={props.required}
      error={error}
      hint={hint}
      className={className}
    >
      <select
        id={id}
        {...props}
        aria-invalid={Boolean(error) || undefined}
        aria-describedby={error || hint ? `${id}-msg` : undefined}
        className="ui-control"
      >
        {children}
      </select>
    </FieldShell>
  );
}

export function TextareaField({
  label,
  error,
  hint,
  className,
  ...props
}: TextareaHTMLAttributes<HTMLTextAreaElement> & {
  label: ReactNode;
  error?: string;
  hint?: ReactNode;
}) {
  const id = useId();
  return (
    <FieldShell
      id={id}
      label={label}
      required={props.required}
      error={error}
      hint={hint}
      className={className}
    >
      <textarea
        id={id}
        rows={3}
        {...props}
        aria-invalid={Boolean(error) || undefined}
        aria-describedby={error || hint ? `${id}-msg` : undefined}
        className="ui-control"
      />
    </FieldShell>
  );
}

/** Checkbox with a label and optional description underneath. */
export function Checkbox({
  label,
  description,
  className,
  ...props
}: Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> & {
  label: ReactNode;
  description?: ReactNode;
}) {
  const id = useId();
  return (
    <div className={cx('flex items-start gap-2.5', className)}>
      <input id={id} type="checkbox" {...props} className="mt-0.5 shrink-0 cursor-pointer" />
      <label htmlFor={id} className="cursor-pointer text-sm leading-5">
        <span className="font-medium text-slate-800">{label}</span>
        {description && <span className="block text-[13px] text-slate-500">{description}</span>}
      </label>
    </div>
  );
}

/** On/off switch for settings. */
export function Switch({
  checked,
  onChange,
  label,
  description,
  disabled,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: ReactNode;
  description?: ReactNode;
  disabled?: boolean;
}) {
  const id = useId();
  return (
    <div className="flex items-start justify-between gap-6">
      <label htmlFor={id} className={cx('text-sm', disabled ? 'cursor-not-allowed' : 'cursor-pointer')}>
        <span className="font-medium text-slate-800">{label}</span>
        {description && <span className="mt-0.5 block text-[13px] text-slate-500">{description}</span>}
      </label>
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={cx(
          'relative mt-0.5 inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors',
          'disabled:cursor-not-allowed disabled:opacity-50',
          checked ? 'bg-brand-600' : 'bg-slate-300',
        )}
      >
        <span
          className={cx(
            'inline-block size-4 rounded-full bg-white shadow-sm transition-transform',
            checked ? 'translate-x-[18px]' : 'translate-x-0.5',
          )}
        />
      </button>
    </div>
  );
}

export function SearchInput({
  value,
  onChange,
  placeholder = 'Search…',
  className,
  label = 'Search',
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  className?: string;
  label?: string;
}) {
  return (
    <div className={cx('relative min-w-0', className)}>
      <Search
        className="pointer-events-none absolute top-1/2 left-2.5 size-4 -translate-y-1/2 text-slate-400"
        aria-hidden="true"
      />
      <input
        type="search"
        aria-label={label}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="ui-control pl-8"
      />
    </div>
  );
}

/** Groups related fields in a form with a small heading. */
export function FormSection({
  title,
  description,
  children,
  className,
}: {
  title: string;
  description?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <fieldset className={cx('min-w-0', className)}>
      <legend className="text-sm font-semibold text-slate-900">{title}</legend>
      {description && <p className="mt-0.5 text-[13px] text-slate-500">{description}</p>}
      <div className="mt-4 grid gap-4 sm:grid-cols-2">{children}</div>
    </fieldset>
  );
}

/** Right-aligned Save / Cancel row at the end of a form. */
export function FormActions({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cx('flex flex-wrap items-center justify-end gap-2 pt-1', className)}>
      {children}
    </div>
  );
}

/* ------------------------------------------------------------------------------------ */
/* Layout                                                                               */
/* ------------------------------------------------------------------------------------ */

export function Card({
  title,
  description,
  actions,
  children,
  className,
  bodyClassName,
  flush,
  icon: Icon,
}: {
  title?: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
  bodyClassName?: string;
  /** Remove body padding (tables, lists that run edge to edge). */
  flush?: boolean;
  icon?: LucideIcon;
}) {
  return (
    <section
      className={cx('min-w-0 rounded-xl border border-line bg-white shadow-card', className)}
    >
      {(title || actions) && (
        <header className="flex flex-wrap items-start justify-between gap-x-4 gap-y-2 border-b border-slate-100 px-5 py-3.5">
          <div className="flex min-w-0 items-start gap-2.5">
            {Icon && (
              <span className="mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-md bg-slate-100 text-slate-600">
                <Icon className="size-4" aria-hidden="true" />
              </span>
            )}
            <div className="min-w-0">
              {title && <h2 className="text-[15px] leading-6 font-semibold text-ink">{title}</h2>}
              {description && <p className="text-[13px] text-slate-500">{description}</p>}
            </div>
          </div>
          {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
        </header>
      )}
      <div
        className={cx(
          flush
            ? ''
            : // Tables run edge to edge inside padded cards.
              'p-5 [&>.ui-bleed]:-mx-5 [&>.ui-bleed:first-child]:-mt-5 [&>.ui-bleed:last-child]:-mb-5',
          !title && !actions && '[&>.ui-bleed:first-child]:rounded-t-xl',
          bodyClassName,
        )}
      >
        {children}
      </div>
    </section>
  );
}

export const PageHeader = ({
  title,
  description,
  actions,
  meta,
}: {
  title: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  /** Small line above the title, e.g. a status badge. */
  meta?: ReactNode;
}) => (
  <div className="mb-6 flex flex-wrap items-start justify-between gap-x-6 gap-y-3">
    <div className="min-w-0">
      {meta && <div className="mb-1.5">{meta}</div>}
      <h1 className="text-xl font-semibold tracking-tight text-ink sm:text-[22px]">{title}</h1>
      {description && <p className="mt-1 max-w-3xl text-sm text-slate-500">{description}</p>}
    </div>
    {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
  </div>
);

/** Row of filters above a table or list. */
export function Toolbar({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cx('mb-4 flex flex-wrap items-end gap-3 [&>*]:min-w-0', className)}>
      {children}
    </div>
  );
}

export function SectionTitle({ children, actions }: { children: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-2 flex items-center justify-between gap-3">
      <h3 className="text-xs font-semibold tracking-wide text-slate-500 uppercase">{children}</h3>
      {actions}
    </div>
  );
}

/* ------------------------------------------------------------------------------------ */
/* Feedback                                                                             */
/* ------------------------------------------------------------------------------------ */

const ALERT_ICON = { error: AlertCircle, info: Info, success: CheckCircle2, warning: AlertTriangle };

export function Alert({
  tone = 'error',
  title,
  children,
  action,
  className,
}: {
  tone?: 'error' | 'info' | 'success' | 'warning';
  title?: ReactNode;
  children: ReactNode;
  action?: ReactNode;
  className?: string;
}) {
  const Icon = ALERT_ICON[tone];
  return (
    <div
      role={tone === 'error' ? 'alert' : 'status'}
      className={cx(
        'flex items-start gap-2.5 rounded-lg border px-3.5 py-2.5 text-sm',
        tone === 'error' && 'border-red-200 bg-red-50 text-red-800',
        tone === 'info' && 'border-brand-100 bg-brand-50 text-brand-800',
        tone === 'success' && 'border-emerald-200 bg-emerald-50 text-emerald-800',
        tone === 'warning' && 'border-amber-200 bg-amber-50 text-amber-900',
        className,
      )}
    >
      <Icon className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
      <div className="min-w-0 flex-1">
        {title && <p className="font-medium">{title}</p>}
        <div className={title ? 'mt-0.5 opacity-90' : ''}>{children}</div>
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

export type BadgeTone = 'neutral' | 'green' | 'amber' | 'red' | 'blue';

export function Badge({
  tone = 'neutral',
  dot,
  children,
  className,
}: {
  tone?: BadgeTone;
  dot?: boolean;
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cx(
        'inline-flex items-center gap-1.5 rounded-md px-1.5 py-0.5 text-xs font-medium whitespace-nowrap ring-1 ring-inset',
        tone === 'neutral' && 'bg-slate-50 text-slate-700 ring-slate-200',
        tone === 'green' && 'bg-emerald-50 text-emerald-700 ring-emerald-200',
        tone === 'amber' && 'bg-amber-50 text-amber-800 ring-amber-200',
        tone === 'red' && 'bg-red-50 text-red-700 ring-red-200',
        tone === 'blue' && 'bg-brand-50 text-brand-700 ring-brand-200',
        className,
      )}
    >
      {dot && (
        <span
          aria-hidden="true"
          className={cx(
            'size-1.5 rounded-full',
            tone === 'neutral' && 'bg-slate-400',
            tone === 'green' && 'bg-emerald-500',
            tone === 'amber' && 'bg-amber-500',
            tone === 'red' && 'bg-red-500',
            tone === 'blue' && 'bg-brand-500',
          )}
        />
      )}
      {children}
    </span>
  );
}

export function Skeleton({ rows = 3, className }: { rows?: number; className?: string }) {
  return (
    <div className={cx('flex flex-col gap-2.5', className)} aria-busy="true" aria-label="Loading">
      {Array.from({ length: rows }, (_, i) => (
        <div
          key={i}
          className="h-9 animate-pulse rounded-lg bg-slate-100"
          style={{ width: `${100 - ((i * 13) % 30)}%` }}
        />
      ))}
    </div>
  );
}

export function SkeletonBlock({ className }: { className?: string }) {
  return <div aria-hidden="true" className={cx('animate-pulse rounded-md bg-slate-100', className)} />;
}

export function EmptyState({
  title,
  children,
  icon: Icon = Inbox,
  action,
  compact,
}: {
  title: string;
  children?: ReactNode;
  icon?: LucideIcon;
  action?: ReactNode;
  compact?: boolean;
}) {
  return (
    <div
      className={cx(
        'flex flex-col items-center text-center',
        compact ? 'gap-1.5 px-4 py-6' : 'gap-2 px-6 py-12',
      )}
    >
      <span
        className={cx(
          'mb-1 flex items-center justify-center rounded-full bg-slate-100 text-slate-500',
          compact ? 'size-9' : 'size-11',
        )}
      >
        <Icon className={compact ? 'size-4' : 'size-5'} aria-hidden="true" />
      </span>
      <p className="text-sm font-semibold text-ink">{title}</p>
      {children && <div className="max-w-sm text-[13px] text-slate-500">{children}</div>}
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}

/* ------------------------------------------------------------------------------------ */
/* Data display                                                                         */
/* ------------------------------------------------------------------------------------ */

export function Table({
  head,
  children,
  className,
}: {
  head: ReactNode[];
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cx('ui-bleed overflow-x-auto', className)}>
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-line bg-slate-50/70">
            {head.map((h, i) => (
              <th
                key={i}
                scope="col"
                className="px-4 py-2.5 text-xs font-medium whitespace-nowrap text-slate-500 first:pl-5 last:pr-5"
              >
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 [&>tr]:transition-colors [&>tr:hover]:bg-slate-50/70">
          {children}
        </tbody>
      </table>
    </div>
  );
}

export const Td = ({
  children,
  className,
  colSpan,
}: {
  children?: ReactNode;
  className?: string;
  colSpan?: number;
}) => (
  <td colSpan={colSpan} className={cx('px-4 py-3 align-middle first:pl-5 last:pr-5', className)}>
    {children}
  </td>
);

export function StatCard({
  label,
  value,
  icon: Icon,
  hint,
  href,
  loading,
}: {
  label: string;
  value: ReactNode;
  icon?: LucideIcon;
  hint?: ReactNode;
  href?: string;
  loading?: boolean;
}) {
  const body = (
    <>
      <div className="flex items-center justify-between gap-2">
        <p className="truncate text-[13px] font-medium text-slate-500">{label}</p>
        {Icon && <Icon className="size-4 shrink-0 text-slate-400" aria-hidden="true" />}
      </div>
      {loading ? (
        <SkeletonBlock className="mt-2 h-7 w-20" />
      ) : (
        <p className="mt-1.5 text-2xl font-semibold tracking-tight text-ink tabular-nums">{value}</p>
      )}
      {hint && <p className="mt-1 truncate text-xs text-slate-500">{hint}</p>}
    </>
  );
  const cls =
    'block min-w-0 rounded-xl border border-line bg-white p-4 shadow-card transition-colors';
  return href ? (
    <Link href={href} className={cx(cls, 'hover:border-slate-300')}>
      {body}
    </Link>
  ) : (
    <div className={cls}>{body}</div>
  );
}

/** Label / value pairs for detail pages. */
export function DescriptionList({
  items,
  columns = 2,
}: {
  items: Array<{ label: string; value: ReactNode }>;
  columns?: 1 | 2 | 3;
}) {
  return (
    <dl
      className={cx(
        'grid gap-x-6 gap-y-4',
        columns === 2 && 'sm:grid-cols-2',
        columns === 3 && 'sm:grid-cols-2 lg:grid-cols-3',
      )}
    >
      {items.map((i) => (
        <div key={i.label} className="min-w-0">
          <dt className="text-xs font-medium text-slate-500">{i.label}</dt>
          <dd className="mt-0.5 text-sm break-words text-ink">{i.value ?? '—'}</dd>
        </div>
      ))}
    </dl>
  );
}

/** Segmented tabs for switching views within a page. */
export function Tabs<T extends string>({
  items,
  value,
  onChange,
  className,
}: {
  items: Array<{ value: T; label: ReactNode; count?: number }>;
  value: T;
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div
      role="tablist"
      className={cx(
        'inline-flex max-w-full gap-0.5 overflow-x-auto rounded-lg bg-slate-100 p-0.5',
        className,
      )}
    >
      {items.map((i) => (
        <button
          key={i.value}
          type="button"
          role="tab"
          aria-selected={value === i.value}
          onClick={() => onChange(i.value)}
          className={cx(
            'inline-flex h-8 items-center gap-1.5 rounded-md px-3 text-[13px] font-medium whitespace-nowrap transition-colors',
            value === i.value
              ? 'bg-white text-ink shadow-card'
              : 'text-slate-600 hover:text-slate-900',
          )}
        >
          {i.label}
          {i.count !== undefined && (
            <span className="rounded bg-slate-200/70 px-1 text-[11px] text-slate-600 tabular-nums">
              {i.count}
            </span>
          )}
        </button>
      ))}
    </div>
  );
}

export function Pagination({
  page,
  pageSize,
  total,
  onPage,
}: {
  page: number;
  pageSize: number;
  total: number;
  onPage: (p: number) => void;
}) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  if (total <= pageSize) return null;
  const from = (page - 1) * pageSize + 1;
  const to = Math.min(total, page * pageSize);
  return (
    <div className="ui-bleed flex items-center justify-between gap-3 border-t border-slate-100 px-5 py-3 text-[13px] text-slate-500">
      <span className="tabular-nums">
        {from}–{to} of {total}
      </span>
      <div className="flex gap-1">
        <Button
          type="button"
          variant="secondary"
          size="sm"
          icon={ChevronLeft}
          aria-label="Previous page"
          disabled={page <= 1}
          onClick={() => onPage(page - 1)}
        />
        <Button
          type="button"
          variant="secondary"
          size="sm"
          icon={ChevronRight}
          aria-label="Next page"
          disabled={page >= pages}
          onClick={() => onPage(page + 1)}
        />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------------------------ */
/* Overlays                                                                             */
/* ------------------------------------------------------------------------------------ */

function useEscape(open: boolean, onClose: () => void) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [open, onClose]);
}

function usePortal() {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  return ready;
}

export function Modal({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  size = 'md',
}: {
  open: boolean;
  onClose: () => void;
  title: ReactNode;
  description?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  size?: 'sm' | 'md' | 'lg';
}) {
  const ready = usePortal();
  const panel = useRef<HTMLDivElement>(null);
  const titleId = useId();
  useEscape(open, onClose);

  useEffect(() => {
    if (!open) return;
    const prev = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    // Focus the first field, otherwise the panel itself.
    const t = setTimeout(() => {
      const first = panel.current?.querySelector<HTMLElement>(
        'input:not([disabled]):not([type=hidden]), select:not([disabled]), textarea:not([disabled])',
      );
      (first ?? panel.current)?.focus();
    }, 10);
    return () => {
      clearTimeout(t);
      document.body.style.overflow = overflow;
      prev?.focus?.();
    };
  }, [open]);

  if (!open || !ready) return null;
  return createPortal(
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-start sm:p-6 sm:pt-[10vh]">
      <div
        className="absolute inset-0 animate-fade-in bg-slate-900/40 backdrop-blur-[1px]"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        ref={panel}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        tabIndex={-1}
        className={cx(
          'relative flex max-h-[90dvh] w-full animate-pop-in flex-col rounded-t-2xl bg-white shadow-pop outline-none sm:rounded-xl',
          size === 'sm' && 'sm:max-w-md',
          size === 'md' && 'sm:max-w-lg',
          size === 'lg' && 'sm:max-w-2xl',
        )}
      >
        <div className="flex items-start justify-between gap-4 border-b border-slate-100 px-5 py-4">
          <div className="min-w-0">
            <h2 id={titleId} className="text-base font-semibold text-ink">
              {title}
            </h2>
            {description && <p className="mt-0.5 text-[13px] text-slate-500">{description}</p>}
          </div>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            icon={X}
            aria-label="Close"
            onClick={onClose}
          />
        </div>
        <div className="overflow-y-auto px-5 py-4">{children}</div>
        {footer && (
          <div className="flex flex-wrap justify-end gap-2 border-t border-slate-100 bg-slate-50/60 px-5 py-3 sm:rounded-b-xl">
            {footer}
          </div>
        )}
      </div>
    </div>,
    document.body,
  );
}

export interface MenuItem {
  label: string;
  icon?: LucideIcon;
  onClick?: () => void;
  href?: string;
  danger?: boolean;
  disabled?: boolean;
  hidden?: boolean;
}

/** "⋯" menu for row actions. Rendered in a portal so tables and cards never clip it. */
export function ActionMenu({ items, label = 'More actions' }: { items: MenuItem[]; label?: string }) {
  const [pos, setPos] = useState<{ top: number; right: number; up: boolean } | null>(null);
  const trigger = useRef<HTMLDivElement>(null);
  const menu = useRef<HTMLDivElement>(null);
  const visible = items.filter((i) => !i.hidden);
  const open = Boolean(pos);
  const close = () => setPos(null);
  useEscape(open, close);
  useEffect(() => {
    if (!open) return;
    const h = (e: MouseEvent) => {
      const t = e.target as Node;
      if (!trigger.current?.contains(t) && !menu.current?.contains(t)) close();
    };
    document.addEventListener('mousedown', h);
    window.addEventListener('resize', close);
    window.addEventListener('scroll', close, true);
    return () => {
      document.removeEventListener('mousedown', h);
      window.removeEventListener('resize', close);
      window.removeEventListener('scroll', close, true);
    };
  }, [open]);
  if (!visible.length) return null;

  const toggle = () => {
    if (open) return close();
    const r = trigger.current!.getBoundingClientRect();
    const up = window.innerHeight - r.bottom < visible.length * 36 + 24;
    setPos({ top: up ? r.top - 4 : r.bottom + 4, right: window.innerWidth - r.right, up });
  };

  return (
    <div ref={trigger} className="inline-block text-left">
      <Button
        type="button"
        variant="ghost"
        size="sm"
        icon={MoreHorizontal}
        aria-label={label}
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={toggle}
      />
      {pos &&
        createPortal(
          <div
            ref={menu}
            role="menu"
            style={{ top: pos.top, right: pos.right }}
            className={cx(
              'fixed z-50 min-w-44 animate-pop-in rounded-lg border border-line bg-white p-1 shadow-pop',
              pos.up && '-translate-y-full',
            )}
          >
            {visible.map((i) => {
              const cls = cx(
                'flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-left text-sm',
                'disabled:pointer-events-none disabled:opacity-50',
                i.danger ? 'text-red-600 hover:bg-red-50' : 'text-slate-700 hover:bg-slate-100',
              );
              const content = (
                <>
                  {i.icon && <i.icon className="size-4 opacity-80" aria-hidden="true" />}
                  {i.label}
                </>
              );
              return i.href ? (
                <Link key={i.label} role="menuitem" href={i.href} className={cls} onClick={close}>
                  {content}
                </Link>
              ) : (
                <button
                  key={i.label}
                  type="button"
                  role="menuitem"
                  disabled={i.disabled}
                  className={cls}
                  onClick={() => {
                    close();
                    i.onClick?.();
                  }}
                >
                  {content}
                </button>
              );
            })}
          </div>,
          document.body,
        )}
    </div>
  );
}

/* ------------------------------------------------------------------------------------ */
/* Confirm dialog + toasts (imperative, rendered once by <OverlayHost/> in the app shell) */
/* ------------------------------------------------------------------------------------ */

interface ConfirmRequest {
  title: string;
  message?: ReactNode;
  confirmLabel?: string;
  tone?: 'danger' | 'primary';
  resolve: (ok: boolean) => void;
}
interface ToastItem {
  id: number;
  tone: 'success' | 'error' | 'info';
  message: ReactNode;
}

const overlay = {
  confirm: null as ConfirmRequest | null,
  toasts: [] as ToastItem[],
  listeners: new Set<() => void>(),
  snapshot: { confirm: null as ConfirmRequest | null, toasts: [] as ToastItem[] },
  emit() {
    this.snapshot = { confirm: this.confirm, toasts: this.toasts };
    this.listeners.forEach((l) => l());
  },
};
let toastSeq = 0;

/**
 * Promise-based replacement for window.confirm().
 * Falls back to the browser dialog if the overlay host is not mounted.
 */
export function confirmAction(opts: Omit<ConfirmRequest, 'resolve'> | string): Promise<boolean> {
  const o = typeof opts === 'string' ? { title: opts } : opts;
  if (!overlay.listeners.size) return Promise.resolve(window.confirm(o.title));
  return new Promise((resolve) => {
    overlay.confirm?.resolve(false);
    overlay.confirm = { tone: 'danger', ...o, resolve };
    overlay.emit();
  });
}

export const toast = Object.assign(
  (message: ReactNode, tone: ToastItem['tone'] = 'info') => {
    const id = ++toastSeq;
    overlay.toasts = [...overlay.toasts, { id, tone, message }].slice(-4);
    overlay.emit();
    setTimeout(() => {
      overlay.toasts = overlay.toasts.filter((t) => t.id !== id);
      overlay.emit();
    }, 4000);
  },
  {
    success: (m: ReactNode) => toast(m, 'success'),
    error: (m: ReactNode) => toast(m, 'error'),
  },
);

export function OverlayHost() {
  const state = useSyncExternalStore(
    (l) => {
      overlay.listeners.add(l);
      return () => overlay.listeners.delete(l);
    },
    () => overlay.snapshot,
    () => overlay.snapshot,
  );
  const c = state.confirm;
  const close = (ok: boolean) => {
    c?.resolve(ok);
    overlay.confirm = null;
    overlay.emit();
  };
  return (
    <>
      <Modal
        open={Boolean(c)}
        onClose={() => close(false)}
        size="sm"
        title={c?.title ?? ''}
        footer={
          <>
            <Button variant="secondary" onClick={() => close(false)}>
              Cancel
            </Button>
            <Button
              variant={c?.tone === 'primary' ? 'primary' : 'danger'}
              onClick={() => close(true)}
              autoFocus
            >
              {c?.confirmLabel ?? 'Confirm'}
            </Button>
          </>
        }
      >
        <p className="text-sm text-slate-600">{c?.message ?? 'This cannot be undone.'}</p>
      </Modal>
      <div
        aria-live="polite"
        className="pointer-events-none fixed right-4 bottom-4 z-[60] flex w-[min(24rem,calc(100vw-2rem))] flex-col gap-2"
      >
        {state.toasts.map((t) => {
          const Icon = t.tone === 'success' ? CheckCircle2 : t.tone === 'error' ? AlertCircle : Info;
          return (
            <div
              key={t.id}
              role={t.tone === 'error' ? 'alert' : 'status'}
              className="pointer-events-auto flex animate-toast-in items-start gap-2.5 rounded-lg border border-line bg-white px-3.5 py-3 text-sm shadow-pop"
            >
              <Icon
                aria-hidden="true"
                className={cx(
                  'mt-0.5 size-4 shrink-0',
                  t.tone === 'success' && 'text-emerald-600',
                  t.tone === 'error' && 'text-red-600',
                  t.tone === 'info' && 'text-brand-600',
                )}
              />
              <div className="min-w-0 flex-1 text-slate-800">{t.message}</div>
            </div>
          );
        })}
      </div>
    </>
  );
}
